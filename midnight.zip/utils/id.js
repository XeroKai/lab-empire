import AsyncStorage from '@react-native-async-storage/async-storage';

const PLAYER_ID_KEY = 'MIDNIGHT_PLAYER_ID';

// Cihaza özel, kalıcı bir oyuncu kimliği üretir/okur.
export async function getOrCreatePlayerId() {
  let id = await AsyncStorage.getItem(PLAYER_ID_KEY);
  if (!id) {
    id = 'p_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
    await AsyncStorage.setItem(PLAYER_ID_KEY, id);
  }
  return id;
}
