// 5 haneli, okuması kolay rastgele oda kodu üretir (10000-99999)
export function generateRoomCode() {
  return String(Math.floor(10000 + Math.random() * 90000));
}
