export const theme = {
  bg: '#0d0d0f',
  card: '#18181b',
  cardBorder: '#28282c',
  text: '#fff',
  textDim: '#9a9aa0',
  accent: '#e8b4ff',
  money: '#7CFC9A',
  warn: '#ffd166',
  danger: '#7a1f2b',
};

export const SKIN_TONES = ['#ffe0bd', '#f1c27d', '#e0ac69', '#c68642', '#8d5524', '#5a3825'];

export const HAIR_COLORS = ['#1a1a1a', '#4a2c17', '#7a4a1e', '#d4a017', '#c0392b', '#e8b4ff', '#7CFC9A'];

export const OUTFIT_COLORS = ['#2b2b30', '#7C4DFF', '#c0392b', '#1f6f4a', '#1a5276', '#8e44ad'];

export const HAIR_STYLES = [
  { id: 'bald', label: 'Kel' },
  { id: 'short', label: 'Kısa' },
  { id: 'long', label: 'Uzun' },
  { id: 'mohawk', label: 'Mohawk' },
];

export const ACCESSORIES = [
  { id: 'none', label: 'Yok', emoji: null },
  { id: 'glasses', label: 'Gözlük', emoji: '🕶️' },
  { id: 'mask', label: 'Maske', emoji: '😷' },
  { id: 'hat', label: 'Şapka', emoji: '🎩' },
];

export function defaultAvatar() {
  return {
    skinTone: SKIN_TONES[0],
    hairColor: HAIR_COLORS[0],
    hairStyle: 'short',
    outfitColor: OUTFIT_COLORS[1],
    accessory: 'none',
  };
}
