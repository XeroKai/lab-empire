import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
  StatusBar,
} from 'react-native';
import { ref, onValue, update, remove, off } from 'firebase/database';
import { db } from '../firebaseConfig';
import AvatarView from '../components/AvatarView';
import { theme } from '../utils/theme';

const INGREDIENTS = [
  { id: 'kimyasal_a', name: 'Bileşen A', cost: 15, quality: 1 },
  { id: 'kimyasal_b', name: 'Bileşen B', cost: 30, quality: 2 },
  { id: 'kimyasal_c', name: 'Katalizör C', cost: 60, quality: 3 },
];

const COOK_TIME_MS = 8000;
const TARGET_MONEY = 3000; // bu miktara ilk ulaşan kazanır

function formatMoney(n) {
  return '₺' + n.toLocaleString('tr-TR');
}

export default function GameScreen({ identity, playerId, roomCode, isHost, onExit }) {
  const [me, setMe] = useState(null); // kendi oyun durumum (local + firebase'e yazılır)
  const [opponent, setOpponent] = useState(null); // rakibin durumu (sadece okunur)
  const [opponentId, setOpponentId] = useState(null);
  const [roomStatus, setRoomStatus] = useState('playing');
  const [winnerId, setWinnerId] = useState(null);
  const [now, setNow] = useState(Date.now());
  const [log, setLog] = useState(['Oyun başladı! Rakibinden önce ₺' + TARGET_MONEY + "'a ulaş."]);
  const firstLoad = useRef(true);
  const meRef = useRef(null);

  // Oda verisini dinle (kendi başlangıç durumum + rakip + oda durumu)
  useEffect(() => {
    const roomRef = ref(db, `rooms/${roomCode}`);
    const unsub = onValue(roomRef, (snap) => {
      const room = snap.val();
      if (!room) {
        Alert.alert('Oda kapandı', 'Oda artık mevcut değil.', [{ text: 'Tamam', onPress: onExit }]);
        return;
      }
      const oppId = room.hostId === playerId ? room.guestId : room.hostId;
      setOpponentId(oppId);
      setRoomStatus(room.status || 'playing');
      setWinnerId(room.winner || null);

      const players = room.players || {};
      if (firstLoad.current && players[playerId]) {
        setMe(players[playerId]);
        firstLoad.current = false;
      }
      if (oppId && players[oppId]) {
        setOpponent(players[oppId]);
      } else if (!firstLoad.current) {
        setOpponent(null);
      }
    });
    return () => off(roomRef);
  }, [roomCode]);

  // Zamanlayıcı tik
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(t);
  }, []);

  // Kendi durumumu her değiştiğinde Firebase'e yaz
  useEffect(() => {
    if (!me) return;
    meRef.current = me;
    update(ref(db, `rooms/${roomCode}/players/${playerId}`), {
      ...me,
      updatedAt: Date.now(),
    }).catch(() => {});
  }, [me]);

  // Üretim bitişini kontrol et
  useEffect(() => {
    if (me && me.cooking && me.cookEndsAt && now >= me.cookEndsAt) {
      setMe((s) => {
        const qualityRoll = Math.min(100, Math.round(30 + (s.lastTier || 1) * 20 + Math.random() * 25));
        addLog(`Üretim tamamlandı! Kalite: %${qualityRoll}.`);
        return {
          ...s,
          cooking: false,
          cookEndsAt: null,
          product: s.product + 1,
          reputation: Math.min(10, s.reputation + (qualityRoll > 70 ? 0.2 : 0)),
        };
      });
    }
  }, [now]);

  // Kazanma koşulunu kontrol et
  useEffect(() => {
    if (me && me.money >= TARGET_MONEY && roomStatus === 'playing') {
      update(ref(db, `rooms/${roomCode}`), { status: 'finished', winner: playerId }).catch(() => {});
    }
  }, [me?.money, roomStatus]);

  const addLog = (line) => setLog((l) => [line, ...l].slice(0, 30));

  const buyIngredient = useCallback((ing) => {
    setMe((s) => {
      if (!s || s.money < ing.cost) {
        addLog(`Yetersiz bakiye: ${ing.name} alınamadı.`);
        return s;
      }
      addLog(`${ing.name} satın alındı (${formatMoney(ing.cost)}).`);
      return {
        ...s,
        money: s.money - ing.cost,
        stock: { ...s.stock, [ing.id]: (s.stock[ing.id] || 0) + 1 },
      };
    });
  }, []);

  const startCooking = useCallback(() => {
    setMe((s) => {
      if (!s || s.cooking) return s;
      const stock = s.stock || {};
      if (!stock.kimyasal_a && !stock.kimyasal_b && !stock.kimyasal_c) {
        addLog('Üretim için en az 1x Bileşen A gerekli.');
        return s;
      }
      let tier = 1;
      const newStock = { ...stock };
      if (newStock.kimyasal_c > 0) {
        newStock.kimyasal_c -= 1;
        tier = 3;
      } else if (newStock.kimyasal_b > 0) {
        newStock.kimyasal_b -= 1;
        tier = 2;
      } else {
        newStock.kimyasal_a -= 1;
        tier = 1;
      }
      addLog('Üretim başladı...');
      return { ...s, stock: newStock, cooking: true, cookEndsAt: Date.now() + COOK_TIME_MS, lastTier: tier };
    });
  }, []);

  const sellProduct = useCallback((amount) => {
    setMe((s) => {
      if (!s || s.product < amount) return s;
      const basePrice = 40 + s.reputation * 8;
      const priceEach = Math.round(basePrice * (0.85 + Math.random() * 0.4));
      const total = priceEach * amount;
      addLog(`${amount} ürün satıldı, kazanç: ${formatMoney(total)}.`);
      return { ...s, product: s.product - amount, money: s.money + total };
    });
  }, []);

  const nextDay = useCallback(() => {
    setMe((s) => {
      addLog(`Gün ${s.day + 1} başladı.`);
      return { ...s, day: s.day + 1 };
    });
  }, []);

  const leaveRoom = useCallback(() => {
    Alert.alert('Odadan Ayrıl', 'Oyundan çıkmak istediğine emin misin?', [
      { text: 'Vazgeç', style: 'cancel' },
      {
        text: 'Ayrıl',
        style: 'destructive',
        onPress: async () => {
          try {
            await remove(ref(db, `rooms/${roomCode}/players/${playerId}`));
          } catch (e) {}
          onExit();
        },
      },
    ]);
  }, [roomCode]);

  if (!me) {
    return (
      <SafeAreaView style={styles.safe}>
        <Text style={styles.loadingText}>Yükleniyor...</Text>
      </SafeAreaView>
    );
  }

  if (roomStatus === 'finished') {
    const iWon = winnerId === playerId;
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.endWrap}>
          <Text style={styles.endEmoji}>{iWon ? '🏆' : '💀'}</Text>
          <Text style={styles.endTitle}>{iWon ? 'KAZANDIN!' : 'RAKİBİN KAZANDI'}</Text>
          <Text style={styles.dim}>Hedef: {formatMoney(TARGET_MONEY)}</Text>
          <Text style={styles.dim}>Senin bakiyen: {formatMoney(me.money)}</Text>
          {opponent && <Text style={styles.dim}>Rakip bakiyesi: {formatMoney(opponent.money)}</Text>}
          <TouchableOpacity style={styles.primaryBtn} onPress={onExit}>
            <Text style={styles.primaryBtnText}>Menüye Dön</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const cookRemaining = me.cooking ? Math.max(0, Math.ceil((me.cookEndsAt - now) / 1000)) : 0;

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={theme.bg} />

      <View style={styles.header}>
        <View style={styles.headerRow}>
          <AvatarView avatar={identity.avatar} size={40} />
          <View style={{ marginLeft: 8, flex: 1 }}>
            <Text style={styles.nickname}>{identity.nickname} (Sen)</Text>
            <Text style={styles.money}>{formatMoney(me.money)} · Gün {me.day}</Text>
          </View>
          <TouchableOpacity onPress={leaveRoom}>
            <Text style={styles.leaveBtn}>Ayrıl</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.opponentRow}>
          {opponent ? (
            <>
              <AvatarView avatar={opponent.avatar} size={36} />
              <Text style={styles.opponentText}>
                {opponent.nickname}: {formatMoney(opponent.money)} · Gün {opponent.day}
              </Text>
            </>
          ) : (
            <Text style={styles.opponentText}>Rakip bağlantısı bekleniyor...</Text>
          )}
        </View>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={{ paddingBottom: 20 }}>
        <Text style={styles.sectionTitle}>Malzeme Marketi</Text>
        {INGREDIENTS.map((ing) => (
          <View key={ing.id} style={styles.card}>
            <View style={styles.row}>
              <View style={{ flex: 1 }}>
                <Text style={styles.cardTitle}>{ing.name}</Text>
                <Text style={styles.cardText}>
                  {formatMoney(ing.cost)} · Sahip olunan: {me.stock?.[ing.id] || 0}
                </Text>
              </View>
              <TouchableOpacity style={styles.smallBtn} onPress={() => buyIngredient(ing)}>
                <Text style={styles.smallBtnText}>Al</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}

        <Text style={styles.sectionTitle}>Laboratuvar</Text>
        <View style={styles.card}>
          <Text style={styles.cardText}>Ürün stoğu: {me.product}</Text>
          <Text style={styles.cardText}>İtibar: {me.reputation.toFixed(1)}/10</Text>
          {me.cooking ? (
            <Text style={styles.cookingText}>Üretiliyor... {cookRemaining}s kaldı</Text>
          ) : (
            <TouchableOpacity style={styles.primaryBtnSmall} onPress={startCooking}>
              <Text style={styles.primaryBtnText}>Üretimi Başlat</Text>
            </TouchableOpacity>
          )}
        </View>

        <Text style={styles.sectionTitle}>Satış</Text>
        <View style={styles.card}>
          <View style={styles.row}>
            <TouchableOpacity
              style={[styles.smallBtn, me.product < 1 && styles.disabled]}
              disabled={me.product < 1}
              onPress={() => sellProduct(1)}
            >
              <Text style={styles.smallBtnText}>1 Sat</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.smallBtn, me.product < 5 && styles.disabled]}
              disabled={me.product < 5}
              onPress={() => sellProduct(5)}
            >
              <Text style={styles.smallBtnText}>5 Sat</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.smallBtn, me.product < 1 && styles.disabled]}
              disabled={me.product < 1}
              onPress={() => sellProduct(me.product)}
            >
              <Text style={styles.smallBtnText}>Tümü</Text>
            </TouchableOpacity>
          </View>
        </View>

        <TouchableOpacity style={styles.primaryBtnSmall} onPress={nextDay}>
          <Text style={styles.primaryBtnText}>Sonraki Güne Geç</Text>
        </TouchableOpacity>

        <Text style={styles.sectionTitle}>Günlük</Text>
        {log.map((l, i) => (
          <Text key={i} style={styles.logLine}>• {l}</Text>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.bg },
  loadingText: { color: '#fff', textAlign: 'center', marginTop: 40 },
  header: {
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: theme.cardBorder,
  },
  headerRow: { flexDirection: 'row', alignItems: 'center' },
  nickname: { color: '#fff', fontSize: 13, fontWeight: '700' },
  money: { color: theme.money, fontSize: 13, fontWeight: '700' },
  leaveBtn: { color: '#ff8080', fontSize: 12, fontWeight: '700' },
  opponentRow: { flexDirection: 'row', alignItems: 'center', marginTop: 10 },
  opponentText: { color: theme.textDim, fontSize: 12, marginLeft: 8 },
  content: { flex: 1, paddingHorizontal: 16, paddingTop: 12 },
  sectionTitle: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '700',
    marginTop: 12,
    marginBottom: 8,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  card: {
    backgroundColor: theme.card,
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: theme.cardBorder,
  },
  cardTitle: { color: theme.accent, fontSize: 14, fontWeight: '700' },
  cardText: { color: '#c9c9cc', fontSize: 12, marginTop: 2 },
  cookingText: { color: theme.warn, fontSize: 13, fontWeight: '700', marginTop: 6 },
  logLine: { color: '#9a9aa0', fontSize: 11, marginBottom: 4 },
  row: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap' },
  primaryBtn: {
    backgroundColor: '#7C4DFF',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 20,
  },
  primaryBtnSmall: {
    backgroundColor: '#7C4DFF',
    borderRadius: 10,
    paddingVertical: 10,
    alignItems: 'center',
    marginTop: 8,
  },
  primaryBtnText: { color: '#fff', fontWeight: '700', fontSize: 13 },
  smallBtn: {
    backgroundColor: '#2b2b30',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 14,
    alignItems: 'center',
    marginRight: 8,
    marginTop: 4,
  },
  smallBtnText: { color: '#fff', fontWeight: '600', fontSize: 12 },
  disabled: { opacity: 0.35 },
  endWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  endEmoji: { fontSize: 60, marginBottom: 10 },
  endTitle: { color: '#fff', fontSize: 24, fontWeight: '800', marginBottom: 14 },
  dim: { color: theme.textDim, fontSize: 13, marginTop: 4 },
});
