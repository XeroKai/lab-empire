import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { ref, set, onValue, onDisconnect, remove, off } from 'firebase/database';
import { db } from '../firebaseConfig';
import { generateRoomCode } from '../utils/roomCode';
import { theme } from '../utils/theme';

function freshPlayerState(identity) {
  return {
    nickname: identity.nickname,
    avatar: identity.avatar,
    money: 500,
    day: 1,
    stock: { kimyasal_a: 2, kimyasal_b: 0, kimyasal_c: 0 },
    product: 0,
    reputation: 1,
    cooking: false,
    cookEndsAt: null,
    updatedAt: Date.now(),
  };
}

export default function HostLobbyScreen({ identity, playerId, onGameStart, onCancel }) {
  const [roomCode, setRoomCode] = useState(null);
  const [status, setStatus] = useState('creating'); // creating | waiting | error
  const roomRefPath = useRef(null);

  useEffect(() => {
    let cancelled = false;
    let unsub = null;

    async function createRoom() {
      for (let attempt = 0; attempt < 6; attempt++) {
        const code = generateRoomCode();
        const roomRef = ref(db, `rooms/${code}`);
        try {
          const snap = await new Promise((resolve, reject) => {
            onValue(roomRef, resolve, reject, { onlyOnce: true });
          });
          if (snap.exists()) continue; // kod dolu, tekrar dene

          await set(roomRef, {
            code,
            status: 'waiting',
            createdAt: Date.now(),
            hostId: playerId,
            guestId: null,
            winner: null,
            players: { [playerId]: freshPlayerState(identity) },
          });

          if (cancelled) return;
          roomRefPath.current = `rooms/${code}`;
          setRoomCode(code);
          setStatus('waiting');

          onDisconnect(roomRef).remove();

          unsub = onValue(roomRef, (s) => {
            const val = s.val();
            if (val && val.guestId && val.status === 'playing') {
              onGameStart({ roomCode: code, isHost: true });
            }
          });
          return;
        } catch (e) {
          if (!cancelled) setStatus('error');
          return;
        }
      }
      if (!cancelled) setStatus('error');
    }

    createRoom();
    return () => {
      cancelled = true;
      if (roomRefPath.current) off(ref(db, roomRefPath.current));
    };
  }, []);

  const cancelRoom = async () => {
    try {
      if (roomRefPath.current) await remove(ref(db, roomRefPath.current));
    } catch (e) {
      // yoksay
    }
    onCancel();
  };

  return (
    <View style={styles.wrap}>
      <Text style={styles.title}>ODA KURULUYOR</Text>

      {status === 'creating' && (
        <View style={styles.center}>
          <ActivityIndicator color={theme.accent} size="large" />
          <Text style={styles.dim}>Oda kodu oluşturuluyor...</Text>
        </View>
      )}

      {status === 'error' && (
        <View style={styles.center}>
          <Text style={styles.errText}>
            Bağlantı kurulamadı. firebaseConfig.js dosyandaki bilgileri kontrol et.
          </Text>
          <TouchableOpacity style={styles.secondaryBtn} onPress={onCancel}>
            <Text style={styles.secondaryBtnText}>Geri Dön</Text>
          </TouchableOpacity>
        </View>
      )}

      {status === 'waiting' && (
        <View style={styles.center}>
          <Text style={styles.dim}>Bu kodu arkadaşına söyle:</Text>
          <View style={styles.codeBox}>
            <Text style={styles.codeText}>{roomCode}</Text>
          </View>
          <ActivityIndicator color={theme.accent} style={{ marginTop: 20 }} />
          <Text style={styles.dim}>Arkadaşının katılması bekleniyor...</Text>
          <TouchableOpacity style={styles.dangerBtn} onPress={cancelRoom}>
            <Text style={styles.secondaryBtnText}>Odayı İptal Et</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: theme.bg, padding: 24, justifyContent: 'center' },
  title: {
    color: theme.accent,
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 30,
    letterSpacing: 1.5,
  },
  center: { alignItems: 'center' },
  dim: { color: theme.textDim, fontSize: 13, marginTop: 10, textAlign: 'center' },
  codeBox: {
    marginTop: 16,
    backgroundColor: theme.card,
    borderWidth: 1,
    borderColor: theme.cardBorder,
    borderRadius: 14,
    paddingHorizontal: 30,
    paddingVertical: 18,
  },
  codeText: { color: '#fff', fontSize: 42, fontWeight: '800', letterSpacing: 8 },
  errText: { color: '#ff8080', fontSize: 13, textAlign: 'center', marginBottom: 16 },
  secondaryBtn: {
    backgroundColor: theme.card,
    borderWidth: 1,
    borderColor: theme.cardBorder,
    borderRadius: 10,
    paddingVertical: 12,
    paddingHorizontal: 24,
    marginTop: 10,
  },
  secondaryBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  dangerBtn: {
    backgroundColor: theme.danger,
    borderRadius: 10,
    paddingVertical: 12,
    paddingHorizontal: 24,
    marginTop: 24,
  },
});
