import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import AvatarView from '../components/AvatarView';
import {
  theme,
  SKIN_TONES,
  HAIR_COLORS,
  OUTFIT_COLORS,
  HAIR_STYLES,
  ACCESSORIES,
  defaultAvatar,
} from '../utils/theme';

export default function IdentityScreen({ initial, onDone }) {
  const [nickname, setNickname] = useState(initial?.nickname || '');
  const [avatar, setAvatar] = useState(initial?.avatar || defaultAvatar());

  const canContinue = nickname.trim().length >= 2;
  const set = (key, value) => setAvatar((a) => ({ ...a, [key]: value }));

  return (
    <ScrollView style={styles.wrap} contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
      <Text style={styles.title}>KARAKTERİNİ OLUŞTUR</Text>

      <View style={styles.previewWrap}>
        <AvatarView avatar={avatar} size={110} />
      </View>

      <Text style={styles.label}>Nickname</Text>
      <TextInput
        style={styles.input}
        value={nickname}
        onChangeText={setNickname}
        placeholder="Örn: Zenith"
        placeholderTextColor="#666"
        maxLength={14}
      />

      <Text style={styles.label}>Ten Rengi</Text>
      <View style={styles.row}>
        {SKIN_TONES.map((c) => (
          <TouchableOpacity
            key={c}
            onPress={() => set('skinTone', c)}
            style={[styles.swatch, { backgroundColor: c }, avatar.skinTone === c && styles.swatchActive]}
          />
        ))}
      </View>

      <Text style={styles.label}>Saç Stili</Text>
      <View style={styles.row}>
        {HAIR_STYLES.map((h) => (
          <TouchableOpacity
            key={h.id}
            onPress={() => set('hairStyle', h.id)}
            style={[styles.chip, avatar.hairStyle === h.id && styles.chipActive]}
          >
            <Text style={[styles.chipText, avatar.hairStyle === h.id && styles.chipTextActive]}>
              {h.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>Saç Rengi</Text>
      <View style={styles.row}>
        {HAIR_COLORS.map((c) => (
          <TouchableOpacity
            key={c}
            onPress={() => set('hairColor', c)}
            style={[styles.swatch, { backgroundColor: c }, avatar.hairColor === c && styles.swatchActive]}
          />
        ))}
      </View>

      <Text style={styles.label}>Kıyafet Rengi</Text>
      <View style={styles.row}>
        {OUTFIT_COLORS.map((c) => (
          <TouchableOpacity
            key={c}
            onPress={() => set('outfitColor', c)}
            style={[styles.swatch, { backgroundColor: c }, avatar.outfitColor === c && styles.swatchActive]}
          />
        ))}
      </View>

      <Text style={styles.label}>Aksesuar</Text>
      <View style={styles.row}>
        {ACCESSORIES.map((a) => (
          <TouchableOpacity
            key={a.id}
            onPress={() => set('accessory', a.id)}
            style={[styles.chip, avatar.accessory === a.id && styles.chipActive]}
          >
            <Text style={[styles.chipText, avatar.accessory === a.id && styles.chipTextActive]}>
              {a.emoji ? `${a.emoji} ` : ''}
              {a.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity
        style={[styles.primaryBtn, !canContinue && styles.disabled]}
        disabled={!canContinue}
        onPress={() => onDone({ nickname: nickname.trim(), avatar })}
      >
        <Text style={styles.primaryBtnText}>Devam Et</Text>
      </TouchableOpacity>
      {!canContinue && <Text style={styles.hint}>Nickname en az 2 karakter olmalı.</Text>}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: theme.bg },
  title: {
    color: theme.accent,
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: 1.5,
    textAlign: 'center',
    marginBottom: 16,
  },
  previewWrap: { alignItems: 'center', marginBottom: 16 },
  label: {
    color: theme.textDim,
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 8,
    marginTop: 14,
    textTransform: 'uppercase',
  },
  input: {
    backgroundColor: theme.card,
    borderWidth: 1,
    borderColor: theme.cardBorder,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    color: theme.text,
    fontSize: 15,
  },
  row: { flexDirection: 'row', flexWrap: 'wrap' },
  swatch: {
    width: 38,
    height: 38,
    borderRadius: 19,
    marginRight: 10,
    marginBottom: 10,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  swatchActive: { borderColor: '#fff' },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: 10,
    backgroundColor: theme.card,
    borderWidth: 1,
    borderColor: theme.cardBorder,
    marginRight: 8,
    marginBottom: 8,
  },
  chipActive: { borderColor: theme.accent, backgroundColor: '#2a2035' },
  chipText: { color: '#aaa', fontSize: 12, fontWeight: '600' },
  chipTextActive: { color: theme.accent },
  primaryBtn: {
    backgroundColor: '#7C4DFF',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 26,
  },
  primaryBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  disabled: { opacity: 0.4 },
  hint: { color: '#888', fontSize: 11, textAlign: 'center', marginTop: 8 },
});
