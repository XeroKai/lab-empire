import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import AvatarView from '../components/AvatarView';
import { theme } from '../utils/theme';

export default function MenuScreen({ identity, onCreateRoom, onJoinRoom, onEditIdentity }) {
  return (
    <View style={styles.wrap}>
      <Text style={styles.gameTitle}>MIDNIGHT</Text>
      <Text style={styles.subtitle}>Çok Oyunculu</Text>

      <TouchableOpacity style={styles.identityCard} onPress={onEditIdentity}>
        <AvatarView avatar={identity.avatar} size={58} />
        <View style={{ marginLeft: 12 }}>
          <Text style={styles.nickname}>{identity.nickname}</Text>
          <Text style={styles.editHint}>Kimliği düzenle</Text>
        </View>
      </TouchableOpacity>

      <TouchableOpacity style={styles.primaryBtn} onPress={onCreateRoom}>
        <Text style={styles.primaryBtnText}>🏠 Oda Oluştur</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.secondaryBtn} onPress={onJoinRoom}>
        <Text style={styles.secondaryBtnText}>🔑 Odaya Katıl</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: theme.bg, padding: 24, justifyContent: 'center' },
  gameTitle: {
    color: theme.accent,
    fontSize: 28,
    fontWeight: '800',
    letterSpacing: 3,
    textAlign: 'center',
  },
  subtitle: { color: theme.textDim, textAlign: 'center', marginBottom: 30, fontSize: 13 },
  identityCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.card,
    borderWidth: 1,
    borderColor: theme.cardBorder,
    borderRadius: 12,
    padding: 14,
    marginBottom: 30,
  },
  nickname: { color: '#fff', fontSize: 16, fontWeight: '700' },
  editHint: { color: '#777', fontSize: 11, marginTop: 2 },
  primaryBtn: {
    backgroundColor: '#7C4DFF',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginBottom: 14,
  },
  primaryBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  secondaryBtn: {
    backgroundColor: theme.card,
    borderWidth: 1,
    borderColor: theme.cardBorder,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
  },
  secondaryBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
