import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
} from 'react-native';
import { ref, get, update } from 'firebase/database';
import { db } from '../firebaseConfig';
import { theme } from '../utils/theme';

function freshPlayerState(identity) {
  return {
    nickname: identity.nickname,
    avatar: identity.avatar,
    money: 500,
    day: 1,
    stock: { kimyasal_a: 2, kimyasal_b: 0, kimyasal_c: 0 },
    product: 0,
    reputation: 1,
    cooking: false,
    cookEndsAt: null,
    updatedAt: Date.now(),
  };
}

export default function JoinLobbyScreen({ identity, playerId, onGameStart, onCancel }) {
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const joinRoom = async () => {
    const trimmed = code.trim();
    if (trimmed.length < 4) {
      setError('Lütfen geçerli bir oda kodu gir.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const roomRef = ref(db, `rooms/${trimmed}`);
      const snap = await get(roomRef);
      if (!snap.exists()) {
        setError('Bu kodda bir oda bulunamadı.');
        setBusy(false);
        return;
      }
      const room = snap.val();
      if (room.status !== 'waiting' || room.guestId) {
        setError('Bu oda dolu veya oyun zaten başlamış.');
        setBusy(false);
        return;
      }
      if (room.hostId === playerId) {
        setError('Kendi odana katılamazsın.');
        setBusy(false);
        return;
      }

      await update(ref(db), {
        [`rooms/${trimmed}/guestId`]: playerId,
        [`rooms/${trimmed}/status`]: 'playing',
        [`rooms/${trimmed}/players/${playerId}`]: freshPlayerState(identity),
      });

      onGameStart({ roomCode: trimmed, isHost: false });
    } catch (e) {
      setError('Bağlantı hatası. firebaseConfig.js dosyanı kontrol et.');
      setBusy(false);
    }
  };

  return (
    <View style={styles.wrap}>
      <Text style={styles.title}>ODAYA KATIL</Text>
      <Text style={styles.dim}>Arkadaşının sana verdiği kodu gir</Text>

      <TextInput
        style={styles.input}
        value={code}
        onChangeText={(t) => setCode(t.replace(/[^0-9]/g, ''))}
        keyboardType="number-pad"
        maxLength={5}
        placeholder="12345"
        placeholderTextColor="#555"
        textAlign="center"
      />

      {!!error && <Text style={styles.errText}>{error}</Text>}

      {busy ? (
        <ActivityIndicator color={theme.accent} style={{ marginTop: 20 }} />
      ) : (
        <TouchableOpacity style={styles.primaryBtn} onPress={joinRoom}>
          <Text style={styles.primaryBtnText}>Katıl</Text>
        </TouchableOpacity>
      )}

      <TouchableOpacity style={styles.secondaryBtn} onPress={onCancel} disabled={busy}>
        <Text style={styles.secondaryBtnText}>Geri Dön</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: theme.bg, padding: 24, justifyContent: 'center' },
  title: {
    color: theme.accent,
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    letterSpacing: 1.5,
  },
  dim: { color: theme.textDim, fontSize: 13, textAlign: 'center', marginTop: 8, marginBottom: 24 },
  input: {
    backgroundColor: theme.card,
    borderWidth: 1,
    borderColor: theme.cardBorder,
    borderRadius: 12,
    paddingVertical: 16,
    color: '#fff',
    fontSize: 28,
    letterSpacing: 6,
    fontWeight: '800',
  },
  errText: { color: '#ff8080', fontSize: 12, textAlign: 'center', marginTop: 12 },
  primaryBtn: {
    backgroundColor: '#7C4DFF',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 20,
  },
  primaryBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  secondaryBtn: { alignItems: 'center', paddingVertical: 14, marginTop: 8 },
  secondaryBtnText: { color: '#888', fontWeight: '600', fontSize: 13 },
});
