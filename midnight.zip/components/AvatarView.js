import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { ACCESSORIES } from '../utils/theme';

// avatar = { skinTone, hairColor, hairStyle, outfitColor, accessory }
export default function AvatarView({ avatar, size = 90 }) {
  if (!avatar) return null;
  const { skinTone, hairColor, hairStyle, outfitColor, accessory } = avatar;

  const headD = size * 0.56;
  const bodyW = size * 0.82;
  const bodyH = size * 0.5;
  const containerH = size * 1.05;

  const accessoryDef = ACCESSORIES.find((a) => a.id === accessory);

  return (
    <View style={[styles.container, { width: size, height: containerH }]}>
      {/* Gövde / kıyafet */}
      <View
        style={[
          styles.body,
          {
            width: bodyW,
            height: bodyH,
            borderTopLeftRadius: size * 0.22,
            borderTopRightRadius: size * 0.22,
            borderBottomLeftRadius: size * 0.12,
            borderBottomRightRadius: size * 0.12,
            backgroundColor: outfitColor,
            bottom: 0,
          },
        ]}
      />

      {/* Kafa */}
      <View
        style={[
          styles.head,
          {
            width: headD,
            height: headD,
            borderRadius: headD / 2,
            backgroundColor: skinTone,
            bottom: bodyH * 0.62,
          },
        ]}
      />

      {/* Saç */}
      {hairStyle === 'short' && (
        <View
          style={[
            styles.hairShort,
            {
              width: headD * 1.08,
              height: headD * 0.42,
              borderTopLeftRadius: headD * 0.55,
              borderTopRightRadius: headD * 0.55,
              backgroundColor: hairColor,
              bottom: bodyH * 0.62 + headD * 0.62,
            },
          ]}
        />
      )}
      {hairStyle === 'long' && (
        <>
          <View
            style={[
              styles.hairShort,
              {
                width: headD * 1.08,
                height: headD * 0.42,
                borderTopLeftRadius: headD * 0.55,
                borderTopRightRadius: headD * 0.55,
                backgroundColor: hairColor,
                bottom: bodyH * 0.62 + headD * 0.62,
              },
            ]}
          />
          <View
            style={[
              styles.hairSide,
              {
                left: size / 2 - headD * 0.62,
                width: headD * 0.26,
                height: headD * 0.9,
                borderRadius: headD * 0.13,
                backgroundColor: hairColor,
                bottom: bodyH * 0.5,
              },
            ]}
          />
          <View
            style={[
              styles.hairSide,
              {
                left: size / 2 + headD * 0.36,
                width: headD * 0.26,
                height: headD * 0.9,
                borderRadius: headD * 0.13,
                backgroundColor: hairColor,
                bottom: bodyH * 0.5,
              },
            ]}
          />
        </>
      )}
      {hairStyle === 'mohawk' && (
        <View
          style={[
            styles.mohawk,
            {
              width: headD * 0.22,
              height: headD * 0.55,
              borderTopLeftRadius: headD * 0.1,
              borderTopRightRadius: headD * 0.1,
              backgroundColor: hairColor,
              bottom: bodyH * 0.62 + headD * 0.55,
            },
          ]}
        />
      )}

      {/* Aksesuar */}
      {accessoryDef?.emoji && (
        <Text
          style={[
            styles.accessoryEmoji,
            { fontSize: headD * 0.42, bottom: bodyH * 0.62 + headD * 0.32 },
          ]}
        >
          {accessoryDef.emoji}
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { position: 'relative', alignItems: 'center' },
  body: { position: 'absolute', alignSelf: 'center' },
  head: { position: 'absolute', alignSelf: 'center' },
  hairShort: { position: 'absolute', alignSelf: 'center' },
  hairSide: { position: 'absolute' },
  mohawk: { position: 'absolute', alignSelf: 'center' },
  accessoryEmoji: { position: 'absolute', alignSelf: 'center' },
});
