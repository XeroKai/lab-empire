import { registerRootComponent } from 'expo';
import App from './App';

// registerRootComponent hem Expo Go'da hem de native derlemede
// doğru giriş noktasını ayarlar.
registerRootComponent(App);
