# Midnight — Çok Oyunculu (Multiplayer)

İki kişinin gerçek zamanlı karşılıklı oynayabildiği, Firebase Realtime Database ile
senkronize edilen bir laboratuvar/ekonomi yarış oyunu. Kimlik oluşturma, oda kurma/katılma
ve canlı senkron oyun akışını içerir. Hedef: rakibinden önce ₺3000'a ulaşmak.

⚠️ **Bu projeyi çalıştırmadan önce mutlaka aşağıdaki "1. Firebase Kurulumu" bölümünü
tamamlaman gerekiyor.** Aksi halde oda kurma/katılma ekranlarında hata alırsın.

---

## 1. Firebase Kurulumu (telefondan, ~5 dakika)

Firebase, Google'ın ücretsiz "serverless" veritabanı hizmetidir — kendi sunucunu kurmana
gerek kalmaz.

1. Telefonunda tarayıcıdan **console.firebase.google.com** adresine git, Google hesabınla giriş yap.
2. **"Proje ekle" / "Add project"** butonuna dokun. Projeye bir isim ver (örn. `midnight`), devam et.
   Google Analytics sorulursa **kapatabilirsin** (gerekli değil), "Proje oluştur"a bas.
3. Proje açıldıktan sonra sol menüden **"Build" → "Realtime Database"**'e gir.
4. **"Create Database"** butonuna dokun. Bölge sorulursa varsayılanı bırakabilirsin.
5. Güvenlik kuralları sorulduğunda **"Start in test mode"** seçeneğini seç (geliştirme aşaması
   için uygundur — herkese açık test amaçlı erişim sağlar).
   > Not: Test modu 30 gün sonra otomatik kapanabilir; oyunu uzun süre kullanacaksan
   > ileride "Rules" sekmesinden `".read": true, ".write": true` şeklinde kalıcı hale getirebilirsin.
6. Sol üstteki dişli ⚙️ ikonuna dokun → **"Project settings"**.
7. Aşağı kaydır, **"Your apps"** bölümünde **"</>"** (Web) simgesine dokun.
8. Uygulamaya bir takma isim ver (örn. `midnight-web`), **"Register app"** de. Firebase
   sana bir kod bloğu (`firebaseConfig`) gösterecek — içinde `apiKey`, `authDomain`,
   `databaseURL`, `projectId`, `storageBucket`, `messagingSenderId`, `appId` alanları var.
9. Bu 6-7 değeri, indirdiğin projedeki **`firebaseConfig.js`** dosyasını GitHub üzerinden
   açıp (dosyaya tıkla → sağ üstteki kalem/✏️ **"Edit"** ikonu) `BURAYA_...` yazan
   yerlerin üzerine yapıştır, sonra **"Commit changes"** ile kaydet.

Bu kadar! Artık iki oyuncu aynı Firebase veritabanı üzerinden senkron oynayabilir.

---

## 2. Telefondan GitHub'a Yükleme ve APK Alma

### Adım 1: GitHub deposu oluştur
1. **github.com** → sağ üst **+** → **New repository** → isim ver → **Create repository**.

### Adım 2: Dosyaları yükle
1. Sana verdiğim `.zip` dosyasını indir, telefonundaki bir dosya yöneticisiyle
   (Files, ZArchiver vb.) **çıkart (extract)**.
2. Depo sayfasında **"Add file" → "Upload files"**, çıkardığın tüm klasör/dosyaları seç, yükle.
3. **"Commit changes"** ile kaydet.
4. (Eğer Firebase bilgilerini henüz girmediysen, Adım 1'deki 9. maddedeki gibi
   `firebaseConfig.js` dosyasını GitHub üzerinden düzenleyip kaydedebilirsin.)

### Adım 3: Otomatik derlemeyi izle
1. **"Actions"** sekmesine gir, **"Build APK"** işleminin başladığını göreceksin.
2. 5-10 dakika sürer. Yeşil tik ✅ olunca işleme gir.

### Adım 4: APK'yı indir
1. Sayfanın altındaki **"Artifacts"** bölümünde `midnight-apk` dosyasına dokun, indir.
2. Zip'i aç, `.apk` dosyasını kur (gerekirse "bilinmeyen kaynaklara izin ver"i onayla).

---

## 3. Oyun Nasıl Oynanır

1. Uygulamayı ilk açtığında **nickname + renk + avatar** seç.
2. Bir oyuncu **"Oda Oluştur"**a basar → ekranda 5 haneli bir kod belirir.
3. Diğer oyuncu bu kodu arkadaşından öğrenip **"Odaya Katıl"**dan girer → oyun otomatik başlar.
4. Her iki taraf da kendi laboratuvarını yönetir (malzeme al, üret, sat); ekranın üstünde
   **rakibin canlı bakiyesi ve günü** görünür.
5. ₺3000'a ilk ulaşan kazanır 🏆.

## ❗ Sorun Giderme
- **"Bağlantı kurulamadı" hatası:** `firebaseConfig.js` içindeki değerleri kontrol et,
  boşluk/eksik karakter olmadığından emin ol.
- **Oda kodu bulunamıyor:** Kodun doğru girildiğinden ve host'un uygulamayı hâlâ açık
  tuttuğundan emin ol (host kapatırsa oda otomatik silinir).
- **Actions kırmızı ❌ ile bitiyor:** İlgili işlemin log'unu aç, hata satırını kopyala,
  bana gönder — birlikte çözeriz.

## 🛠 Sonraki Adımlar
Eklenebilecekler: yeniden oynama/rövanş butonu, sohbet kutusu, sabotaj/rekabet
mekanikleri (rakibin fiyatını düşürme vb.), ses efektleri, gerçek uygulama ikonu.
Hangisini istersen söyle, birlikte ekleyelim.
