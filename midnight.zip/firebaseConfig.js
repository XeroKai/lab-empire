// ============================================================
// FIREBASE AYARLARI — BU DOSYAYI KENDİ BİLGİLERİNLE DOLDUR
// ============================================================
// Aşağıdaki 6 alanı, Firebase Console'dan aldığın "firebaseConfig"
// nesnesindeki gerçek değerlerle değiştir. README.md dosyasındaki
// "Firebase Kurulumu" bölümünde bunları nereden bulacağın adım adım
// anlatılıyor.
//
// ÖNEMLİ: databaseURL alanını boş bırakma — Realtime Database'i
// Firebase Console'da aktifleştirdiğinde otomatik oluşur, mutlaka
// "https://...firebasedatabase.app" ile başlar.

import { initializeApp, getApps, getApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';

const firebaseConfig = {
  apiKey: 'BURAYA_API_KEY',
  authDomain: 'BURAYA_PROJE_ADI.firebaseapp.com',
  databaseURL: 'https://BURAYA_PROJE_ADI-default-rtdb.firebaseio.com',
  projectId: 'BURAYA_PROJE_ADI',
  storageBucket: 'BURAYA_PROJE_ADI.appspot.com',
  messagingSenderId: 'BURAYA_SENDER_ID',
  appId: 'BURAYA_APP_ID',
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const db = getDatabase(app);
export default app;
