const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Firebase JS SDK'nin "package.json exports" yapısı Metro bundler ile
// çakışabiliyor. Bu satır olmadan derleme sırasında Firebase modülleri
// bulunamama hatası (module not found) alınabilir.
config.resolver.unstable_enablePackageExports = false;

module.exports = config;
